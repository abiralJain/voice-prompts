"use client";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 border-b border-[var(--border)]/80 bg-[var(--bg)]/80 backdrop-blur-md">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 md:px-8">
        <a
          href="#top"
          className="font-[family-name:var(--font-heading)] text-lg font-bold tracking-tight text-white transition hover:text-[var(--accent-blue)]"
        >
          VoicePrompt
        </a>
        <div className="flex items-center gap-6 text-sm text-[var(--text-secondary)]">
          <a href="#how-it-works" className="transition hover:text-white">
            How it works
          </a>
          <a href="#tools" className="transition hover:text-white">
            Tools
          </a>
          <a
            href="/test"
            className="text-[var(--text-tertiary)] transition hover:text-[var(--accent-blue)]"
          >
            Dev
          </a>
        </div>
      </nav>
    </header>
  );
}
