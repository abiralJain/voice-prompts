"use client";

import { useSpeechRecognition, useSpeechSupported } from "@/lib/speechRecognition";
import type { RefineResponse } from "@/types";
import EditableTranscript from "./EditableTranscript";
import FeedbackSection from "./FeedbackSection";
import RefinedPromptBlock from "./RefinedPromptBlock";
import ToolCategoryDisplay from "./ToolCategoryDisplay";

interface ResultsStateProps {
  results: RefineResponse;
  transcript: string;
  onTranscriptChange: (value: string) => void;
  activeToolIndex: number;
  onActiveToolChange: (index: number) => void;
  onReRefine: (extraFeedback?: string) => Promise<void>;
  onTryAnother: () => void;
}

export default function ResultsState({
  results,
  transcript,
  onTranscriptChange,
  activeToolIndex,
  onActiveToolChange,
  onReRefine,
  onTryAnother,
}: ResultsStateProps) {
  const supported = useSpeechSupported();
  const speech = useSpeechRecognition({
    onInterim: (live) => onTranscriptChange(live),
  });

  const transcriptChanged =
    transcript.trim() !== (results.original_transcript ?? "").trim();

  const activeTool = results.tools[activeToolIndex] ?? results.tools[0];

  const toggleAppendMic = () => {
    if (!supported) return;
    if (speech.isListening) {
      speech.stop();
      window.setTimeout(() => {
        const merged = speech.getMergedTranscript();
        if (merged) onTranscriptChange(merged);
      }, 120);
    } else {
      speech.start(transcript.trim() ? transcript : undefined);
    }
  };

  return (
    <div className="mx-auto w-full max-w-6xl px-4 pb-12 pt-4 md:px-8">
      <div className="grid gap-10 lg:grid-cols-2 lg:gap-12">
        <div className="space-y-3">
          <p className="text-xs font-semibold uppercase tracking-widest text-[var(--text-tertiary)]">
            What you said
          </p>
          <div className="relative">
            {supported ? (
              <button
                type="button"
                onClick={toggleAppendMic}
                className="absolute right-3 top-3 z-10 rounded-full border border-[var(--border)] bg-[var(--surface)] p-2 text-sm shadow-md transition hover:border-[var(--accent-blue)]/50"
                aria-label="Add more with voice"
              >
                {speech.isListening ? "■" : "🎤"}
              </button>
            ) : null}
            <EditableTranscript
              value={transcript}
              onChange={onTranscriptChange}
              className="pr-14"
            />
          </div>
          {speech.error ? <p className="text-sm text-[var(--error)]">{speech.error}</p> : null}
          <button
            type="button"
            disabled={!transcriptChanged || speech.isListening}
            onClick={() => onReRefine()}
            className="rounded-full border border-[var(--accent-blue)]/50 bg-[var(--accent-blue)]/10 px-5 py-2 text-sm font-semibold text-[var(--accent-blue)] transition hover:bg-[var(--accent-blue)]/20 disabled:cursor-not-allowed disabled:opacity-40"
          >
            Re-refine
          </button>
        </div>

        <div>
          {activeTool ? (
            <RefinedPromptBlock
              tool={activeTool}
              categoryLabel={results.category_label}
              animationKey={activeToolIndex}
              improvementsMade={results.improvements_made}
            />
          ) : null}
        </div>
      </div>

      <ToolCategoryDisplay
        results={results}
        activeToolIndex={activeToolIndex}
        onSelectTool={onActiveToolChange}
      />

      <FeedbackSection
        onTryAnother={onTryAnother}
        onReRefineWithFeedback={async (fb) => {
          await onReRefine(fb);
        }}
      />
    </div>
  );
}
