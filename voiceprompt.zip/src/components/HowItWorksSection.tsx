"use client";

import { useRevealOnScroll } from "@/hooks/useRevealOnScroll";

const STEPS = [
  {
    n: "01",
    title: "Speak",
    body: "Talk naturally. Filler words and detours are fine — we extract the real intent.",
    icon: "🎙️",
  },
  {
    n: "02",
    title: "Refine",
    body: "Gemini classifies the task, picks the best tools, and rewrites prompts per tool.",
    icon: "✨",
  },
  {
    n: "03",
    title: "Use",
    body: "Copy a production-ready prompt, switch tools instantly, and ship faster.",
    icon: "🚀",
  },
];

export default function HowItWorksSection() {
  const { ref, visible } = useRevealOnScroll<HTMLElement>();

  return (
    <section
      id="how-it-works"
      ref={ref}
      className={`reveal-on-scroll border-t border-[var(--border)] bg-[var(--surface)]/30 py-24 ${visible ? "is-visible" : ""}`}
    >
      <div className="mx-auto max-w-6xl px-4 md:px-8">
        <h2 className="mb-12 text-center font-[family-name:var(--font-heading)] text-3xl font-bold text-white md:text-4xl">
          How it works
        </h2>
        <div className="grid gap-8 md:grid-cols-3">
          {STEPS.map((step) => (
            <article
              key={step.n}
              className="rounded-2xl border border-[var(--border)] bg-[var(--bg)]/60 p-8 transition hover:border-[var(--accent-blue)]/40 hover:bg-[var(--surface-hover)]"
            >
              <div className="mb-4 flex items-center gap-3">
                <span className="text-2xl" aria-hidden>
                  {step.icon}
                </span>
                <span className="rounded-full bg-white/10 px-2 py-0.5 font-mono text-xs text-[var(--accent-blue)]">
                  {step.n}
                </span>
              </div>
              <h3 className="mb-2 font-[family-name:var(--font-heading)] text-xl font-semibold text-white">
                {step.title}
              </h3>
              <p className="text-sm leading-relaxed text-[var(--text-secondary)]">{step.body}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
