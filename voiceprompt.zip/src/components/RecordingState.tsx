"use client";

import { useEffect, useMemo, useState } from "react";
import { useSpeechRecognition, useSpeechSupported } from "@/lib/speechRecognition";
import AudioWaveform, { type WaveformMode } from "./AudioWaveform";
import EditableTranscript from "./EditableTranscript";

function wordCount(text: string) {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

interface RecordingStateProps {
  transcript: string;
  onTranscriptChange: (value: string) => void;
  audioStream: MediaStream | null;
  ensureMic: () => Promise<void>;
  stopMic: () => void;
  onRefine: () => void;
  onClearRestart: () => void;
  processing?: boolean;
}

export default function RecordingState({
  transcript,
  onTranscriptChange,
  audioStream,
  ensureMic,
  stopMic,
  onRefine,
  onClearRestart,
  processing = false,
}: RecordingStateProps) {
  const supported = useSpeechSupported();
  const speech = useSpeechRecognition({
    onInterim: (live) => onTranscriptChange(live),
  });
  const { stop: stopSpeech } = speech;
  const [shortHint, setShortHint] = useState(false);

  useEffect(() => {
    void ensureMic();
  }, [ensureMic]);

  useEffect(() => {
    if (processing) stopSpeech();
  }, [processing, stopSpeech]);

  const waveformMode: WaveformMode = processing
    ? "thinking"
    : speech.isListening
      ? "listening"
      : "idle";

  const canRefine = wordCount(transcript) >= 10 && !processing;

  const statusLabel = useMemo(() => {
    if (processing) return "Analyzing your intent and finding the best tools...";
    if (speech.isListening)
      return (
        <span className="inline-flex items-center gap-2">
          <span
            className="inline-block h-2 w-2 animate-pulse rounded-full bg-[var(--accent-blue)]"
            aria-hidden
          />
          I&apos;m listening...
        </span>
      );
    return "Tap the mic to continue speaking";
  }, [processing, speech.isListening]);

  const toggleMic = () => {
    setShortHint(false);
    if (speech.isListening) {
      speech.stop();
      window.setTimeout(() => {
        const merged = speech.getMergedTranscript();
        if (merged) onTranscriptChange(merged);
        const wc = wordCount(merged || transcript);
        if (wc > 0 && wc < 10) setShortHint(true);
      }, 120);
    } else {
      void ensureMic();
      speech.start(transcript.trim() ? transcript : undefined);
    }
  };

  return (
    <div className="flex min-h-[calc(100dvh-4.5rem)] flex-col items-center justify-center gap-8 px-4 pb-20 pt-6">
      <p className="min-h-[1.5rem] text-center text-sm text-[var(--text-secondary)]">{statusLabel}</p>

      <div className="relative flex flex-col items-center gap-6">
        <button
          type="button"
          onClick={toggleMic}
          disabled={processing || !supported}
          className={`relative flex h-28 w-28 items-center justify-center rounded-full text-3xl text-white transition ${
            speech.isListening ? "animate-[pulse-soft_1.6s_ease-in-out_infinite]" : ""
          } disabled:cursor-not-allowed disabled:opacity-50`}
          aria-label={speech.isListening ? "Stop recording" : "Start recording"}
        >
          <span
            className="absolute inset-0 rounded-full p-[3px]"
            style={{
              background: "linear-gradient(135deg, #00C2FF, #7C5CFC)",
            }}
          >
            <span className="flex h-full w-full items-center justify-center rounded-full bg-[var(--bg)]">
              <span
                className="flex h-[calc(100%-6px)] w-[calc(100%-6px)] items-center justify-center rounded-full"
                style={{
                  background: "linear-gradient(135deg, rgba(0,194,255,0.25), rgba(124,92,252,0.35))",
                }}
              >
                {speech.isListening ? "■" : "🎤"}
              </span>
            </span>
          </span>
        </button>

        <AudioWaveform stream={audioStream} mode={waveformMode} />
      </div>

      {!supported ? (
        <p className="max-w-md text-center text-sm text-amber-200/90">
          Voice input works best in Chrome or Edge. You can still type your transcript below.
        </p>
      ) : null}

      <div className="w-full max-w-2xl space-y-3">
        <EditableTranscript
          value={transcript}
          onChange={onTranscriptChange}
          disabled={processing}
        />
        {shortHint ? (
          <p className="text-center text-sm text-[var(--text-secondary)]">
            That seems a bit short. Want to add more detail for a better result?
          </p>
        ) : null}
        {speech.error ? <p className="text-center text-sm text-[var(--error)]">{speech.error}</p> : null}
      </div>

      {!processing ? (
        <div className="flex w-full max-w-2xl flex-col gap-3 sm:flex-row sm:justify-center">
          <button
            type="button"
            disabled={!canRefine}
            onClick={onRefine}
            className="btn-gradient flex-1 rounded-full px-8 py-3 text-base font-semibold disabled:cursor-not-allowed disabled:opacity-40 disabled:shadow-none"
          >
            Refine Prompt
          </button>
          <button
            type="button"
            onClick={() => {
              speech.stop();
              speech.reset();
              stopMic();
              onTranscriptChange("");
              onClearRestart();
            }}
            className="flex-1 rounded-full border border-[var(--border)] bg-transparent px-6 py-3 text-sm font-medium text-[var(--text-secondary)] transition hover:border-[var(--accent-blue)]/50 hover:text-white"
          >
            Clear &amp; restart
          </button>
        </div>
      ) : null}
    </div>
  );
}
