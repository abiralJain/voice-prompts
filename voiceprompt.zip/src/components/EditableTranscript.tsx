"use client";

interface EditableTranscriptProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
}

export default function EditableTranscript({
  value,
  onChange,
  placeholder = "Your words will appear here...",
  disabled = false,
  className = "",
}: EditableTranscriptProps) {
  return (
    <div
      className={`rounded-2xl border border-[var(--border)] bg-[var(--surface)]/90 p-1 shadow-inner ${className}`}
    >
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        placeholder={placeholder}
        rows={6}
        className="min-h-[160px] w-full resize-y rounded-xl bg-transparent px-4 py-3 text-sm leading-relaxed text-[var(--text-primary)] outline-none placeholder:text-[var(--text-tertiary)] focus:ring-2 focus:ring-[var(--accent-blue)]/30 disabled:opacity-60 md:text-base"
      />
    </div>
  );
}
