"use client";

import type { ToolPrompt } from "@/types";

interface ToolCardProps {
  tool: ToolPrompt;
  isBest: boolean;
  isActive: boolean;
  onViewPrompt: () => void;
}

export default function ToolCard({ tool, isBest, isActive, onViewPrompt }: ToolCardProps) {
  return (
    <article
      className={`relative flex h-full flex-col rounded-2xl border p-6 transition ${
        isBest
          ? "gradient-border scale-[1.02] border-transparent bg-[var(--surface)] shadow-xl shadow-[var(--accent-purple)]/10"
          : "border-[var(--border)] bg-[var(--surface)]/80 hover:-translate-y-0.5 hover:shadow-lg"
      } ${isActive ? "ring-2 ring-[var(--accent-blue)]/50" : ""}`}
    >
      {isBest ? (
        <span className="absolute -top-3 left-4 rounded-full bg-[var(--accent-gradient)] px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-[#08090e]">
          Best match
        </span>
      ) : null}
      <div className="mb-3 flex items-center gap-2">
        <span className="text-2xl" aria-hidden>
          {tool.tool_icon}
        </span>
        <h3 className="font-[family-name:var(--font-heading)] text-lg font-semibold text-white">
          {tool.tool_name}
        </h3>
      </div>
      <p className="mb-4 flex-1 text-sm text-[var(--text-secondary)]">
        <span className="font-medium text-[var(--text-primary)]">Best for:</span> {tool.best_for}
      </p>
      <div className="mb-4 flex items-center gap-2">
        <span
          className={`rounded-full px-2 py-0.5 text-xs font-semibold ${
            tool.is_free ? "bg-[var(--success)]/15 text-[var(--success)]" : "bg-white/10 text-[var(--text-secondary)]"
          }`}
        >
          {tool.is_free ? "Free" : "Paid"}
        </span>
      </div>
      <button
        type="button"
        onClick={onViewPrompt}
        className="mt-auto w-full rounded-xl border border-[var(--border)] py-2.5 text-sm font-semibold text-white transition hover:border-[var(--accent-blue)]/60 hover:bg-white/5"
      >
        View prompt →
      </button>
    </article>
  );
}
