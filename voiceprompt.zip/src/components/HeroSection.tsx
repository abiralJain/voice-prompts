"use client";

import type { RefObject } from "react";
import type { HeroState, RefineResponse } from "@/types";
import LandingState from "./LandingState";
import RecordingState from "./RecordingState";
import ResultsState from "./ResultsState";

interface HeroSectionProps {
  heroState: HeroState;
  transcript: string;
  onTranscriptChange: (value: string) => void;
  results: RefineResponse | null;
  activeToolIndex: number;
  onActiveToolChange: (index: number) => void;
  audioStream: MediaStream | null;
  ensureMic: () => Promise<void>;
  stopMic: () => void;
  onStartSpeaking: () => void;
  onRecordingClearRestart: () => void;
  onRefine: () => Promise<void>;
  onReRefine: (feedback?: string) => Promise<void>;
  onTryAnother: () => void;
  resultsRef: RefObject<HTMLDivElement | null>;
}

export default function HeroSection({
  heroState,
  transcript,
  onTranscriptChange,
  results,
  activeToolIndex,
  onActiveToolChange,
  audioStream,
  ensureMic,
  stopMic,
  onStartSpeaking,
  onRecordingClearRestart,
  onRefine,
  onReRefine,
  onTryAnother,
  resultsRef,
}: HeroSectionProps) {
  return (
    <section id="top" className="scroll-mt-24">
      {heroState === "landing" ? (
        <div className="animate-fade-in">
          <LandingState onStartSpeaking={onStartSpeaking} />
        </div>
      ) : null}

      {heroState === "recording" || heroState === "processing" ? (
        <div className="animate-fade-in">
          <RecordingState
            transcript={transcript}
            onTranscriptChange={onTranscriptChange}
            audioStream={audioStream}
            ensureMic={ensureMic}
            stopMic={stopMic}
            onRefine={onRefine}
            onClearRestart={onRecordingClearRestart}
            processing={heroState === "processing"}
          />
        </div>
      ) : null}

      {heroState === "results" && results ? (
        <div ref={resultsRef} className="animate-fade-in">
          <ResultsState
            results={results}
            transcript={transcript}
            onTranscriptChange={onTranscriptChange}
            activeToolIndex={activeToolIndex}
            onActiveToolChange={onActiveToolChange}
            onReRefine={onReRefine}
            onTryAnother={onTryAnother}
          />
        </div>
      ) : null}
    </section>
  );
}
