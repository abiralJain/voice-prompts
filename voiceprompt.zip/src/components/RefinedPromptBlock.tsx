"use client";

import { useState } from "react";
import type { ToolPrompt } from "@/types";
import CopyButton from "./CopyButton";

interface RefinedPromptBlockProps {
  tool: ToolPrompt;
  categoryLabel: string;
  animationKey: number;
  improvementsMade: string[];
}

export default function RefinedPromptBlock({
  tool,
  categoryLabel,
  animationKey,
  improvementsMade,
}: RefinedPromptBlockProps) {
  const [open, setOpen] = useState(false);

  return (
    <div key={animationKey} className="crossfade-enter space-y-4">
      <div className="gradient-border rounded-2xl bg-[var(--surface)]/90 p-5 shadow-lg">
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-sm font-semibold text-white">
            <span aria-hidden>{tool.tool_icon}</span>
            {tool.tool_name}
            <span className="text-xs font-normal text-[var(--text-secondary)]">
              · {categoryLabel}
            </span>
          </span>
        </div>
        <p className="text-xs font-medium uppercase tracking-wide text-[var(--text-tertiary)]">
          Why this tool
        </p>
        <p className="mt-1 text-sm text-[var(--text-secondary)]">{tool.prompt_explanation}</p>
      </div>

      <div className="relative rounded-2xl border border-[var(--border)] bg-[#0c0e14] p-5 shadow-inner">
        <div className="mb-3 flex items-start justify-end gap-2">
          <CopyButton text={tool.refined_prompt} className="shrink-0" />
        </div>
        <p className="whitespace-pre-wrap font-[family-name:var(--font-mono)] text-sm leading-relaxed text-[#e8e6ff] md:text-[15px]">
          {tool.refined_prompt}
        </p>
      </div>

      <div>
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          className="text-sm font-medium text-[var(--accent-blue)] transition hover:text-[var(--accent-purple)]"
        >
          {open ? "Hide" : "What we improved"}
        </button>
        {open ? (
          <ul className="mt-3 list-disc space-y-1 pl-5 text-sm text-[var(--text-secondary)]">
            {improvementsMade.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        ) : null}
      </div>
    </div>
  );
}
