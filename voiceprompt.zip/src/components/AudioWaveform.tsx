"use client";

import { useEffect, useRef } from "react";

export type WaveformMode = "idle" | "listening" | "thinking";

interface AudioWaveformProps {
  stream: MediaStream | null;
  mode: WaveformMode;
}

export default function AudioWaveform({ stream, mode }: AudioWaveformProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const dataRef = useRef<Uint8Array<ArrayBuffer> | null>(null);
  const smoothAmpRef = useRef(0);
  const frameRef = useRef(0);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    if (mode !== "listening" || !stream) {
      if (sourceRef.current) {
        try {
          sourceRef.current.disconnect();
        } catch {
          /* ignore */
        }
        sourceRef.current = null;
      }
      if (audioContextRef.current && audioContextRef.current.state !== "closed") {
        void audioContextRef.current.close();
      }
      audioContextRef.current = null;
      analyserRef.current = null;
      dataRef.current = null;
      return;
    }

    const audioCtx = new AudioContext();
    const source = audioCtx.createMediaStreamSource(stream);
    const analyser = audioCtx.createAnalyser();
    analyser.fftSize = 2048;
    analyser.smoothingTimeConstant = 0.82;
    source.connect(analyser);
    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(new ArrayBuffer(bufferLength)) as Uint8Array<ArrayBuffer>;

    audioContextRef.current = audioCtx;
    analyserRef.current = analyser;
    sourceRef.current = source;
    dataRef.current = dataArray;

    void audioCtx.resume();

    return () => {
      try {
        source.disconnect();
      } catch {
        /* ignore */
      }
      sourceRef.current = null;
      analyserRef.current = null;
      dataRef.current = null;
      if (audioCtx.state !== "closed") {
        void audioCtx.close();
      }
      audioContextRef.current = null;
    };
  }, [stream, mode]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const resize = () => {
      const parent = canvas.parentElement;
      const w = parent?.clientWidth ?? 600;
      const cssH = 96;
      const dpr = typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(cssH * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${cssH}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    resize();
    const ro = new ResizeObserver(resize);
    if (canvas.parentElement) ro.observe(canvas.parentElement);

    const draw = () => {
      rafRef.current = requestAnimationFrame(draw);
      frameRef.current += 1;
      const t = frameRef.current;
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      ctx.clearRect(0, 0, w, h);

      let targetAmp = 0.06;
      if (mode === "listening" && analyserRef.current && dataRef.current) {
        analyserRef.current.getByteTimeDomainData(dataRef.current);
        const arr = dataRef.current;
        let sum = 0;
        for (let i = 0; i < arr.length; i += 1) {
          const v = (arr[i]! - 128) / 128;
          sum += v * v;
        }
        targetAmp = Math.min(0.55, Math.sqrt(sum / arr.length) * 2.2 + 0.04);
      } else if (mode === "thinking") {
        targetAmp = 0.12 + 0.1 * Math.sin(t * 0.06);
      } else {
        targetAmp = 0.05 + 0.035 * Math.sin(t * 0.04);
      }

      smoothAmpRef.current += (targetAmp - smoothAmpRef.current) * 0.12;
      const amp = smoothAmpRef.current;
      const mid = h / 2;
      const points = 80;

      const grad = ctx.createLinearGradient(0, 0, w, 0);
      grad.addColorStop(0, "#00C2FF");
      grad.addColorStop(1, "#7C5CFC");

      ctx.save();
      ctx.strokeStyle = grad;
      ctx.lineWidth = 2;
      ctx.lineJoin = "round";
      ctx.lineCap = "round";
      ctx.shadowBlur = 14;
      ctx.shadowColor = "rgba(124, 92, 252, 0.45)";
      ctx.beginPath();
      for (let i = 0; i <= points; i += 1) {
        const x = (i / points) * w;
        const phase = t * (mode === "thinking" ? 0.09 : 0.055) + i * 0.28;
        const envelope = mode === "thinking" ? 1 : 0.85 + 0.15 * Math.sin(i * 0.08 + t * 0.02);
        const y = mid + Math.sin(phase) * amp * h * 0.42 * envelope;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.restore();
    };

    rafRef.current = requestAnimationFrame(draw);
    return () => {
      ro.disconnect();
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
    };
  }, [mode]);

  return (
    <div className="mx-auto w-[min(100%,42rem)]">
      <canvas ref={canvasRef} className="block w-full" aria-hidden />
    </div>
  );
}
