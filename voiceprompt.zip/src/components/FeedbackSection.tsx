"use client";

import { useState } from "react";

interface FeedbackSectionProps {
  onTryAnother: () => void;
  onReRefineWithFeedback: (feedback: string) => Promise<void>;
}

export default function FeedbackSection({ onTryAnother, onReRefineWithFeedback }: FeedbackSectionProps) {
  const [celebrated, setCelebrated] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [feedback, setFeedback] = useState("");
  const [busy, setBusy] = useState(false);

  const handleReRefine = async () => {
    if (!feedback.trim()) return;
    setBusy(true);
    try {
      await onReRefineWithFeedback(feedback.trim());
      setExpanded(false);
      setFeedback("");
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="mt-16 rounded-2xl border border-[var(--border)] bg-[var(--surface)]/60 p-8">
      <h3 className="mb-6 text-center font-[family-name:var(--font-heading)] text-lg font-semibold text-white">
        Did this hit the mark?
      </h3>

      {celebrated ? (
        <div className="animate-fade-in text-center">
          <div className="pointer-events-none mb-6 flex justify-center gap-2" aria-hidden>
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <span
                key={i}
                className="inline-block h-2 w-2 rounded-full bg-[var(--accent-blue)] opacity-80"
                style={{
                  animation: `float 1.2s ease-in-out ${i * 0.08}s infinite`,
                }}
              />
            ))}
          </div>
          <p className="mb-6 text-[var(--text-secondary)]">Want to try another?</p>
          <button
            type="button"
            onClick={() => {
              setCelebrated(false);
              onTryAnother();
            }}
            className="btn-gradient rounded-full px-8 py-3 text-sm font-semibold"
          >
            🎤 Speak a new idea
          </button>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
          <button
            type="button"
            onClick={() => setCelebrated(true)}
            className="rounded-full border border-[var(--success)]/40 bg-[var(--success)]/10 px-6 py-2.5 text-sm font-semibold text-[var(--success)] transition hover:bg-[var(--success)]/20"
          >
            Yes, perfect ✓
          </button>
          <button
            type="button"
            onClick={() => setExpanded((e) => !e)}
            className="rounded-full border border-[var(--border)] px-6 py-2.5 text-sm font-semibold text-[var(--text-secondary)] transition hover:border-[var(--accent-purple)]/50 hover:text-white"
          >
            Not quite →
          </button>
        </div>
      )}

      {expanded && !celebrated ? (
        <div className="animate-slide-up mt-8 space-y-4 border-t border-[var(--border)] pt-8">
          <p className="text-sm text-[var(--text-secondary)]">
            What would you like to change? Add detail below — we&apos;ll fold it into a fresh refinement.
          </p>
          <textarea
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            rows={4}
            className="w-full rounded-xl border border-[var(--border)] bg-[#0c0e14] px-4 py-3 text-sm text-white outline-none focus:ring-2 focus:ring-[var(--accent-blue)]/30"
            placeholder="e.g. Make it more technical, add constraints, target a different tool..."
          />
          <button
            type="button"
            disabled={!feedback.trim() || busy}
            onClick={handleReRefine}
            className="btn-gradient rounded-full px-6 py-2.5 text-sm font-semibold disabled:opacity-40"
          >
            {busy ? "Re-refining…" : "Re-refine"}
          </button>
        </div>
      ) : null}
    </section>
  );
}
