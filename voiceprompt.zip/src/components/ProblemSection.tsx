"use client";

import { useRevealOnScroll } from "@/hooks/useRevealOnScroll";

export default function ProblemSection() {
  const { ref, visible } = useRevealOnScroll<HTMLElement>();

  return (
    <section
      ref={ref}
      className={`reveal-on-scroll mx-auto max-w-6xl px-4 py-24 md:px-8 ${visible ? "is-visible" : ""}`}
    >
      <h2 className="mb-4 max-w-3xl font-[family-name:var(--font-heading)] text-3xl font-bold leading-tight text-white md:text-4xl">
        You use AI every day.{" "}
        <span className="text-[var(--text-secondary)]">But your prompts hold you back.</span>
      </h2>
      <p className="mb-12 max-w-2xl text-[var(--text-secondary)]">
        Rambling voice notes and vague requests waste tokens and time. VoicePrompt turns what you
        actually mean into tool-native prompts that get results.
      </p>
      <div className="grid gap-6 md:grid-cols-2">
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6">
          <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-[var(--error)]">
            Before
          </p>
          <p className="font-[family-name:var(--font-mono)] text-sm italic leading-relaxed text-[var(--text-tertiary)]">
            &ldquo;umm so like build me something cool for my shop idk modern maybe&rdquo;
          </p>
        </div>
        <div className="gradient-border rounded-2xl bg-[var(--surface)] p-6">
          <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-[var(--success)]">
            After
          </p>
          <p className="font-[family-name:var(--font-mono)] text-sm leading-relaxed text-[var(--text-primary)]">
            Clear objective, stack, layout, interactions, accessibility, and success criteria —
            tuned for the tool you&rsquo;re using.
          </p>
        </div>
      </div>
    </section>
  );
}
