"use client";

import AnimatedDemo from "./AnimatedDemo";

interface LandingStateProps {
  onStartSpeaking: () => void;
}

export default function LandingState({ onStartSpeaking }: LandingStateProps) {
  return (
    <div className="flex min-h-[calc(100dvh-4.5rem)] flex-col items-center justify-center gap-10 px-4 pb-16 pt-8 md:gap-14">
      <div className="max-w-3xl text-center">
        <h1 className="mb-5 font-[family-name:var(--font-heading)] text-4xl font-bold leading-tight tracking-tight text-white md:text-5xl lg:text-6xl">
          Stop typing.{" "}
          <span className="gradient-text">Start talking.</span>
        </h1>
        <p className="mx-auto max-w-[60ch] text-base text-[var(--text-secondary)] md:text-lg">
          Transform messy spoken thoughts into perfectly structured prompts for any AI tool.
        </p>
      </div>

      <AnimatedDemo />

      <button
        type="button"
        onClick={onStartSpeaking}
        className="btn-gradient flex items-center gap-3 rounded-full px-10 py-4 text-lg"
      >
        <span className="text-xl" aria-hidden>
          🎤
        </span>
        Start speaking
      </button>
    </div>
  );
}
