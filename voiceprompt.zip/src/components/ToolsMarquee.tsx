const TOOLS = [
  "ChatGPT",
  "Claude",
  "Midjourney",
  "Cursor",
  "Suno",
  "Runway",
  "v0",
  "Perplexity",
  "DALL-E",
  "Figma",
  "ElevenLabs",
  "Stable Diffusion",
  "Kling",
  "Pika",
  "Ideogram",
  "Bolt",
  "Lovable",
  "Gamma",
  "Whimsical",
  "NotebookLM",
];

export default function ToolsMarquee() {
  const row = [...TOOLS, ...TOOLS];
  return (
    <section id="tools" className="border-y border-[var(--border)] bg-[var(--surface)]/40 py-16">
      <div className="mx-auto max-w-6xl px-4 md:px-8">
        <h2 className="mb-8 text-center font-[family-name:var(--font-heading)] text-2xl font-bold text-white md:text-3xl">
          Optimized for <span className="gradient-text">50+ AI tools</span>
        </h2>
        <div className="group relative overflow-hidden py-2">
          <div className="flex w-max animate-[marquee_40s_linear_infinite] gap-3 group-hover:[animation-play-state:paused]">
            {row.map((name, i) => (
              <span
                key={`${name}-${i}`}
                className="shrink-0 rounded-full border border-[var(--border)] bg-[var(--bg)]/80 px-3 py-1 text-xs text-[var(--text-secondary)]"
              >
                {name}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
