export default function Footer() {
  return (
    <footer className="border-t border-[var(--border)] bg-[var(--surface)]/50 py-12">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 px-4 text-center text-sm text-[var(--text-secondary)] md:flex-row md:justify-between md:px-8 md:text-left">
        <p>
          Built by{" "}
          <a
            href="https://abiraljain.com"
            target="_blank"
            rel="noreferrer"
            className="text-[var(--accent-blue)] transition hover:underline"
          >
            Abiral Jain
          </a>
        </p>
        <div className="flex gap-6">
          <a href="#top" className="transition hover:text-white">
            Back to top
          </a>
          <a href="/test" className="transition hover:text-white">
            Test lab
          </a>
        </div>
      </div>
    </footer>
  );
}
