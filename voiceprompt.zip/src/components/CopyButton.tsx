"use client";

import { useState } from "react";

interface CopyButtonProps {
  text: string;
  className?: string;
  label?: string;
}

export default function CopyButton({ text, className = "", label = "Copy" }: CopyButtonProps) {
  const [copied, setCopied] = useState(false);
  const [failed, setFailed] = useState(false);

  const handleCopy = async () => {
    if (!text.trim()) return;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setFailed(false);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setFailed(true);
      window.setTimeout(() => setFailed(false), 2000);
    }
  };

  return (
    <button
      type="button"
      onClick={handleCopy}
      disabled={!text.trim()}
      className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
        copied
          ? "bg-[var(--success)]/20 text-[var(--success)] ring-1 ring-[var(--success)]/40"
          : "bg-white/10 text-white hover:bg-white/15"
      } disabled:cursor-not-allowed disabled:opacity-40 ${className}`}
      aria-label="Copy to clipboard"
    >
      {failed ? "Failed" : copied ? "✓ Copied!" : label}
    </button>
  );
}
