"use client";

import { useMemo, useState } from "react";
import type { RefineResponse } from "@/types";
import ToolCard from "./ToolCard";

interface ToolCategoryDisplayProps {
  results: RefineResponse;
  activeToolIndex: number;
  onSelectTool: (index: number) => void;
}

export default function ToolCategoryDisplay({
  results,
  activeToolIndex,
  onSelectTool,
}: ToolCategoryDisplayProps) {
  const [expanded, setExpanded] = useState(false);
  const topThree = results.tools.slice(0, 3);

  const topNames = useMemo(() => new Set(topThree.map((t) => t.tool_name)), [topThree]);

  const extra = useMemo(
    () => results.all_category_tools.filter((t) => !topNames.has(t.name)),
    [results.all_category_tools, topNames],
  );

  return (
    <section className="mt-14 space-y-8">
      <h3 className="font-[family-name:var(--font-heading)] text-xl font-bold text-white md:text-2xl">
        All tools for this task
      </h3>
      <div className="grid gap-6 md:grid-cols-3">
        {topThree.map((tool, index) => (
          <ToolCard
            key={tool.tool_name}
            tool={tool}
            isBest={index === results.best_match_index}
            isActive={activeToolIndex === index}
            onViewPrompt={() => onSelectTool(index)}
          />
        ))}
      </div>
      {extra.length > 0 ? (
        <div className="space-y-3">
          <button
            type="button"
            onClick={() => setExpanded((e) => !e)}
            className="text-sm font-medium text-[var(--accent-blue)] transition hover:underline"
          >
            {expanded ? "Hide" : `See all ${extra.length} tools in this category →`}
          </button>
          {expanded ? (
            <div className="flex flex-wrap gap-2">
              {extra.map((t) => (
                <span
                  key={t.name}
                  className="rounded-full border border-[var(--border)] bg-white/5 px-3 py-1 text-xs text-[var(--text-secondary)]"
                  title={t.best_for}
                >
                  {t.icon} {t.name}
                </span>
              ))}
            </div>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}
