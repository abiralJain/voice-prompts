"use client";

import { useRevealOnScroll } from "@/hooks/useRevealOnScroll";

interface FinalCTAProps {
  onScrollToHero: () => void;
}

export default function FinalCTA({ onScrollToHero }: FinalCTAProps) {
  const { ref, visible } = useRevealOnScroll<HTMLElement>();

  return (
    <section
      ref={ref}
      className={`reveal-on-scroll py-24 ${visible ? "is-visible" : ""}`}
    >
      <div className="mx-auto max-w-6xl px-4 md:px-8">
        <div className="rounded-3xl border border-[var(--border)] bg-gradient-to-br from-[var(--surface)] to-[var(--bg)] p-10 text-center md:p-16">
          <h2 className="mb-4 font-[family-name:var(--font-heading)] text-3xl font-bold text-white md:text-4xl">
            Ready to speak?
          </h2>
          <p className="mx-auto mb-8 max-w-xl text-[var(--text-secondary)]">
            Jump back to the hero and start your first refinement in seconds.
          </p>
          <button
            type="button"
            onClick={onScrollToHero}
            className="btn-gradient inline-flex items-center gap-2 rounded-full px-8 py-4 text-base"
          >
            <span aria-hidden>🎤</span>
            Start speaking
          </button>
        </div>
      </div>
    </section>
  );
}
