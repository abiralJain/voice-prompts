"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import FinalCTA from "@/components/FinalCTA";
import Footer from "@/components/Footer";
import HeroSection from "@/components/HeroSection";
import HowItWorksSection from "@/components/HowItWorksSection";
import Navbar from "@/components/Navbar";
import ProblemSection from "@/components/ProblemSection";
import ToolsMarquee from "@/components/ToolsMarquee";
import type { HeroState, RefineResponse } from "@/types";

function wordCount(text: string) {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

export default function HomePage() {
  const [heroState, setHeroState] = useState<HeroState>("landing");
  const [transcript, setTranscript] = useState("");
  const [results, setResults] = useState<RefineResponse | null>(null);
  const [activeToolIndex, setActiveToolIndex] = useState(0);
  const [audioStream, setAudioStream] = useState<MediaStream | null>(null);
  const [bannerError, setBannerError] = useState<string | null>(null);

  const streamRef = useRef<MediaStream | null>(null);
  const resultsRef = useRef<HTMLDivElement | null>(null);

  const ensureMic = useCallback(async () => {
    if (streamRef.current) return;
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = s;
      setAudioStream(s);
    } catch {
      setBannerError("Microphone unavailable — you can still type your transcript.");
      window.setTimeout(() => setBannerError(null), 4000);
    }
  }, []);

  const stopMic = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setAudioStream(null);
  }, []);

  const scrollToHero = useCallback(() => {
    document.getElementById("top")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, []);

  const runRefine = useCallback(
    async (text: string) => {
      const res = await fetch("/api/refine", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ transcript: text }),
      });
      const data = (await res.json()) as RefineResponse & { error?: string };
      if (!res.ok) {
        throw new Error(data.error || "Refinement failed");
      }
      if (!Array.isArray(data.tools) || data.tools.length < 3) {
        throw new Error("Unexpected response from AI. Please try again.");
      }
      const normalized: RefineResponse = {
        ...data,
        tools: data.tools.slice(0, 3),
        all_category_tools: data.all_category_tools ?? [],
        improvements_made: data.improvements_made ?? [],
        original_transcript: data.original_transcript ?? text,
        category_label: data.category_label || data.category,
        best_match_index: data.best_match_index ?? 0,
      };
      setResults(normalized);
      setTranscript(normalized.original_transcript);
      setActiveToolIndex(
        Math.min(normalized.best_match_index ?? 0, normalized.tools.length - 1),
      );
      setHeroState("results");
    },
    [],
  );

  const handleRefine = useCallback(async () => {
    if (wordCount(transcript) < 10) return;
    setBannerError(null);
    setHeroState("processing");
    stopMic();
    try {
      await runRefine(transcript.trim());
      requestAnimationFrame(() => {
        resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    } catch (e: unknown) {
      const message = e instanceof Error ? e.message : "Something went wrong";
      setBannerError(message);
      setHeroState("recording");
    }
  }, [runRefine, stopMic, transcript]);

  const handleReRefine = useCallback(
    async (feedback?: string) => {
      const base = transcript.trim();
      const payload = feedback
        ? `${base}\n\n--- User feedback ---\n${feedback.trim()}`
        : base;
      setBannerError(null);
      try {
        await runRefine(payload);
        requestAnimationFrame(() => {
          resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
        });
      } catch (e: unknown) {
        const message = e instanceof Error ? e.message : "Something went wrong";
        setBannerError(message);
      }
    },
    [runRefine, transcript],
  );

  const handleTryAnother = useCallback(() => {
    stopMic();
    setResults(null);
    setTranscript("");
    setActiveToolIndex(0);
    setHeroState("landing");
  }, [stopMic]);

  const handleRecordingClearRestart = useCallback(() => {
    stopMic();
    setHeroState("landing");
    setTranscript("");
  }, [stopMic]);

  const handleStartSpeaking = useCallback(() => {
    setBannerError(null);
    setHeroState("recording");
    void ensureMic();
  }, [ensureMic]);

  useEffect(() => {
    return () => {
      streamRef.current?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  return (
    <div className="flex min-h-dvh flex-col">
      <Navbar />
      {bannerError ? (
        <div className="border-b border-[var(--error)]/40 bg-[var(--error)]/10 px-4 py-3 text-center text-sm text-[var(--error)]">
          {bannerError}
        </div>
      ) : null}

      <HeroSection
        heroState={heroState}
        transcript={transcript}
        onTranscriptChange={setTranscript}
        results={results}
        activeToolIndex={activeToolIndex}
        onActiveToolChange={setActiveToolIndex}
        audioStream={audioStream}
        ensureMic={ensureMic}
        stopMic={stopMic}
        onStartSpeaking={handleStartSpeaking}
        onRecordingClearRestart={handleRecordingClearRestart}
        onRefine={handleRefine}
        onReRefine={handleReRefine}
        onTryAnother={handleTryAnother}
        resultsRef={resultsRef}
      />

      <ProblemSection />
      <HowItWorksSection />
      <ToolsMarquee />
      <FinalCTA onScrollToHero={scrollToHero} />

      <Footer />
    </div>
  );
}
