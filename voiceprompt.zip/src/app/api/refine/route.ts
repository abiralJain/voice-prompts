import { refineTranscript } from "@/lib/gemini";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const { transcript } = await request.json();

    if (!transcript || typeof transcript !== "string") {
      return NextResponse.json({ error: "Transcript is required" }, { status: 400 });
    }

    const trimmed = transcript.trim();
    const wordCount = trimmed.split(/\s+/).filter(Boolean).length;
    if (wordCount < 5) {
      return NextResponse.json(
        { error: "Transcript too short. Need at least 5 words." },
        { status: 400 },
      );
    }

    const result = await refineTranscript(trimmed);
    return NextResponse.json({
      ...result,
      original_transcript: result.original_transcript ?? trimmed,
    });
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : "Something went wrong. Please try again.";
    console.error("Refine API error:", error);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
