export interface ToolPrompt {
  tool_name: string;
  tool_icon: string;
  best_for: string;
  is_free: boolean;
  refined_prompt: string;
  prompt_explanation: string;
}

export interface RefineResponse {
  category: string;
  category_label: string;
  tools: ToolPrompt[];
  best_match_index: number;
  original_transcript: string;
  improvements_made: string[];
  all_category_tools: {
    name: string;
    icon: string;
    best_for: string;
    is_free: boolean;
  }[];
}

export type HeroState = "landing" | "recording" | "processing" | "results";

export type RecordingStatus = "idle" | "recording" | "stopped";
